            <div class="left side-menu">
                <div class="sidebar-inner slimscrollleft">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <ul>
                        	<li class="menu-title">Navigation</li>

                            <li class="has_sub">
                                <a href="dashboard.php" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Dashboard </span> </a>
                         
                            </li>
							
                            <li class="has_sub">
                                <a href="manage-suggestion.php" class="waves-effect"><i class="fa fa-commenting-o" aria-hidden="true"></i><span> Suggestion </span> </a>
                         
                            </li>
							
                            <li class="has_sub">
                                <a href="manage-member.php" class="waves-effect"><i class="fa fa-envelope" aria-hidden="true"></i> <span> Enquiry </span> </a>
                         
                            </li>
		 					
                            <li class="has_sub">
                                <a href="manage-mailus.php" class="waves-effect"><i class="fa fa-phone" aria-hidden="true"></i> <span> Contact Us </span> </a>
                         
                            </li>

							
 							
							 <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-bell"></i> <span> Notification  </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="add-notification.php">Add Notification </a></li>
                                    <li><a href="manage-notification.php">Manage Notification </a></li>
                                    
                                </ul>
                             </li> 
							 <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-user" aria-hidden="true"></i> <span> Vendor  </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                     <li><a href="add-vendor.php">Add vendor </a></li>
                                     <li><a href="manage-vendor.php">Activ vendor </a></li>
									  <li><a href="manage-inactive-vendor.php">De Activ vendor </a></li>
                                     <li><a href="add-bus.php">Add Bus </a></li>
                                     <li><a href="manage-bus.php">Manage Bus </a></li>                                   
                                </ul>
                             </li> 
							
							 <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-globe" aria-hidden="true"></i> <span> city  </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="add-city.php">Add city </a></li>
                                    <li><a href="manage-city.php">Manage city </a></li>
                                    <li><a href="add-type.php">Add Bus Type </a></li>
                                    <li><a href="manage-type.php">Manage Bus Type </a></li>                                    
                                </ul>
                            </li>  

							 <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-phone"></i> <span> Depot  </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="add-depot.php">Add Depot </a></li>
                                    <li><a href="manage-depot.php">Manage Depot </a></li>
                                    
                                </ul>
                            </li> 
                             <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-list"></i> <span> Report  </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="manage-report.php">Manage Report </a></li>
                                    
                                </ul>
                            </li> 
							
            
 
            
			
			
   			
			
                        </ul>
                    </div>
                    <!-- Sidebar -->
                    <div class="clearfix"></div>

 

                </div>
                <!-- Sidebar -left -->

            </div>